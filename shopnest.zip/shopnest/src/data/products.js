const products = [
  {
    id: 1,
    title: "Wireless Headphones",
    price: 1999,
    image:
      "https://m.media-amazon.com/images/I/61CGHv6kmWL._SL1500_.jpg",
  },
  {
    id: 2,
    title: "Smart Watch",
    price: 2499,
    image:
      "https://m.media-amazon.com/images/I/61y2VVWcGBL._SL1500_.jpg",
  },
];

export default products;