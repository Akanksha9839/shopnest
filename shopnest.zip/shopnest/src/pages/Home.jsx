export default function Home() {
  return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      <h1>Welcome to ShopNest 🛒</h1>
      <p>Go to Products to start shopping</p>
    </div>
  );
}